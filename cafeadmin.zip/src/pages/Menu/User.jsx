import TableComponent from "../TableComponent/TableComponent";
import { Box, Button, Typography, Chip } from "@mui/material";
import { useNavigate } from "react-router-dom";
import { Edit, Eye, Trash2, Plus } from "lucide-react";
import { useMemo } from "react";

const UserList = () => {
  const navigate = useNavigate();

  // 🔹 Table Columns
  const columns = useMemo(
    () => [
     
      {
        accessorKey: "name",
        header: "Full Name",
      },
     
      {
        accessorKey: "phoneNumber",
        header: "Phone Number",
      },
   
      {
        accessorKey: "tablenumber",
        header: "Table  Number",
        Cell: ({ row }) => row.original.tablenumber || "-",
      },
    ],
    []
  );

  // 🔹 Actions
  const actions = [
    
  ];

  return (
    <div className="overflow-hidden">
      {/* Header */}
      <Box
        sx={{
          p: 3,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <Typography variant="h6" fontWeight={600}>
          User Management
        </Typography>

        <Button
          variant="contained"
          sx={{ backgroundColor: "#6F4E37" }}
          startIcon={<Plus size={18} />}
          onClick={() => navigate("/users/create")}
        >
          Create User
        </Button>
      </Box>

      {/* Table */}
      <TableComponent
        slug="users"
        columns={columns}
        actions={actions}
        actionsType="users"
        querykey="user"
        getApiEndPoint="user_list"
        deleteApiEndPoint="customer/delete"
        deleteAction={true}
        enableExportTable={true}
      />
      
    </div>
    
  );
};

export default UserList;
