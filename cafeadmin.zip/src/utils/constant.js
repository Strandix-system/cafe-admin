export const AUTH_ROLES = {
    ADMIN: 'admin',
    SUPER_ADMIN: 'superadmin'
}